// === Config ===
const VOTING_DEADLINE = new Date(localStorage.getItem('egrok_deadline') || '2025-07-30T23:59:59');
const CATEGORY_COLORS = ['#6c5ce7', '#00cec9', '#fd79a8', '#fdcb6e', '#e17055', '#00b894'];

// === Default Contestants (with real photos from randomuser.me) ===
const defaultContestants = [
  { id: 1, name: 'Amara Okafor', category: 'Best Performer', image: 'https://randomuser.me/api/portraits/women/44.jpg', bio: 'Award-winning stage artist with 5 years of excellence in performing arts and public speaking.', simVotes: 142 },
  { id: 2, name: 'Daniel Mensah', category: 'Most Creative', image: 'https://randomuser.me/api/portraits/men/32.jpg', bio: 'Innovative designer and creative director known for pushing boundaries in visual storytelling.', simVotes: 98 },
  { id: 3, name: 'Fatima Al-Rashid', category: 'Best Leader', image: 'https://randomuser.me/api/portraits/women/68.jpg', bio: 'Visionary leader who has mentored over 200 professionals across global organizations.', simVotes: 215 },
  { id: 4, name: 'James Okonkwo', category: 'Most Innovative', image: 'https://randomuser.me/api/portraits/men/75.jpg', bio: 'Tech entrepreneur with 3 patents and a passion for solving real-world problems through technology.', simVotes: 67 },
  { id: 5, name: 'Sofia Rodriguez', category: 'Best Teamwork', image: 'https://randomuser.me/api/portraits/women/90.jpg', bio: 'Collaborative spirit who led cross-functional teams to deliver award-winning projects on time.', simVotes: 183 },
  { id: 6, name: 'Kwame Asante', category: 'Rising Star', image: 'https://randomuser.me/api/portraits/men/22.jpg', bio: 'Emerging talent making waves in the industry with fresh ideas and relentless drive.', simVotes: 54 },
  { id: 7, name: 'Chioma Eze', category: 'Best Performer', image: 'https://randomuser.me/api/portraits/women/33.jpg', bio: 'Captivating vocalist and dancer whose performances have graced international stages.', simVotes: 127 },
  { id: 8, name: 'Marcus Johnson', category: 'Most Creative', image: 'https://randomuser.me/api/portraits/men/46.jpg', bio: 'Multimedia artist blending traditional techniques with cutting-edge digital tools.', simVotes: 89 },
  { id: 9, name: 'Aisha Bello', category: 'Best Leader', image: 'https://randomuser.me/api/portraits/women/55.jpg', bio: 'Community organizer who built a network of 50+ youth empowerment programs across Africa.', simVotes: 176 },
  { id: 10, name: 'Emeka Nwosu', category: 'Most Innovative', image: 'https://randomuser.me/api/portraits/men/64.jpg', bio: 'AI researcher developing solutions for healthcare accessibility in underserved communities.', simVotes: 112 },
  { id: 11, name: 'Zara Ibrahim', category: 'Best Teamwork', image: 'https://randomuser.me/api/portraits/women/17.jpg', bio: 'Project manager known for uniting diverse teams and delivering results under pressure.', simVotes: 145 },
  { id: 12, name: 'Tunde Adeyemi', category: 'Rising Star', image: 'https://randomuser.me/api/portraits/men/11.jpg', bio: 'Young entrepreneur whose startup has already impacted thousands of lives in West Africa.', simVotes: 73 },
];

// === Load contestants (defaults + admin-added) ===
function getContestants() {
  const custom = JSON.parse(localStorage.getItem('egrok_custom_contestants') || '[]');
  return [...defaultContestants, ...custom];
}

let contestants = getContestants();

// === DOM ===
const grid = document.getElementById('contestantsGrid');
const noResults = document.getElementById('noResults');
const searchInput = document.getElementById('searchInput');
const filterTabs = document.getElementById('filterTabs');
const categoryList = document.getElementById('categoryList');
const liveFeed = document.getElementById('liveFeed');
const topList = document.getElementById('topList');
const successOverlay = document.getElementById('successOverlay');

let activeFilter = 'all';
const hasVoted = () => localStorage.getItem('egrok_voted') === 'true';

// Load vote counts: simulated base + real localStorage votes
function loadVotes() {
  const votes = JSON.parse(localStorage.getItem('egrok_votes') || '[]');
  contestants.forEach(c => {
    const realVotes = votes.filter(v => v.candidate === c.name).length;
    c.votes = (c.simVotes || 0) + realVotes;
  });
}

// === Render Cards ===
function renderCards() {
  const filter = searchInput.value.toLowerCase();
  const filtered = contestants.filter(c => {
    const matchSearch = c.name.toLowerCase().includes(filter) || c.category.toLowerCase().includes(filter);
    const matchCategory = activeFilter === 'all' || c.category === activeFilter;
    return matchSearch && matchCategory;
  });

  grid.innerHTML = '';
  noResults.hidden = filtered.length > 0;

  filtered.forEach(c => {
    const colorIdx = contestants.indexOf(c) % CATEGORY_COLORS.length;
    const color = CATEGORY_COLORS[colorIdx];
    const fallback = `https://ui-avatars.com/api/?name=${encodeURIComponent(c.name)}&size=400&background=${color.replace('#','')}&color=fff&bold=true`;
    const adminImg = localStorage.getItem(`egrok_img_${c.id}`);
    const imgSrc = adminImg || c.image;
    const voted = hasVoted();

    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="card-image-wrap">
        <img src="${imgSrc}" alt="${c.name}" onerror="this.src='${fallback}'">
        <span class="card-badge" style="background:${color}">${c.category}</span>
      </div>
      <div class="card-body">
        <div class="card-name">${c.name}</div>
        <div class="card-category">${c.category}</div>
        <p class="card-bio">${c.bio}</p>
      </div>
      <div class="card-footer">
        <span class="card-votes"><i class="fa-solid fa-heart"></i> ${c.votes.toLocaleString()} votes</span>
        <button class="btn-vote ${voted ? '' : 'vote-active'}" data-id="${c.id}" ${voted ? 'disabled' : ''}>
          ${voted ? '<i class="fa-solid fa-check"></i> Voted' : '<i class="fa-solid fa-bolt"></i> Vote'}
        </button>
      </div>`;
    grid.appendChild(card);
  });
}

// === Categories ===
function renderCategories() {
  const categories = [...new Set(contestants.map(c => c.category))];

  categoryList.innerHTML = '';
  categories.forEach((cat, i) => {
    const tag = document.createElement('div');
    tag.className = `category-tag${activeFilter === cat ? ' active' : ''}`;
    tag.innerHTML = `<span class="category-dot" style="background:${CATEGORY_COLORS[i % CATEGORY_COLORS.length]}"></span>${cat}`;
    tag.addEventListener('click', () => { activeFilter = activeFilter === cat ? 'all' : cat; renderAll(); });
    categoryList.appendChild(tag);
  });

  const existing = filterTabs.querySelectorAll('.filter-tab:not([data-filter="all"])');
  existing.forEach(t => t.remove());
  categories.forEach(cat => {
    const tab = document.createElement('button');
    tab.className = `filter-tab${activeFilter === cat ? ' active' : ''}`;
    tab.dataset.filter = cat;
    tab.textContent = cat;
    filterTabs.appendChild(tab);
  });
  filterTabs.querySelector('[data-filter="all"]').className = `filter-tab${activeFilter === 'all' ? ' active' : ''}`;
}

// === Live Feed ===
function renderLiveFeed() {
  const votes = JSON.parse(localStorage.getItem('egrok_votes') || '[]');

  // Generate simulated feed entries
  const simNames = ['Adaeze N.', 'Chidi O.', 'Blessing A.', 'Yusuf M.', 'Grace T.', 'Kola B.', 'Ngozi E.', 'Ibrahim S.'];
  const simFeed = simNames.map((name, i) => ({
    name,
    candidate: contestants[i % contestants.length]?.name || 'Unknown',
    timestamp: new Date(Date.now() - (i + 1) * 300000).toISOString(),
    simulated: true
  }));

  const allFeed = [...votes, ...simFeed].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)).slice(0, 10);

  if (!allFeed.length) { liveFeed.innerHTML = '<p class="feed-empty">No votes yet. Be the first!</p>'; return; }

  liveFeed.innerHTML = '';
  allFeed.forEach(v => {
    const item = document.createElement('div');
    item.className = 'feed-item';
    const ago = getTimeAgo(new Date(v.timestamp));
    item.innerHTML = `<span class="feed-dot"></span><span><strong>${v.name}</strong> voted for <strong>${v.candidate}</strong> · ${ago}</span>`;
    liveFeed.appendChild(item);
  });
}

function getTimeAgo(date) {
  const s = Math.floor((Date.now() - date) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + 'm ago';
  if (s < 86400) return Math.floor(s / 3600) + 'h ago';
  return Math.floor(s / 86400) + 'd ago';
}

// === Top Contestants ===
function renderTopList() {
  const sorted = [...contestants].sort((a, b) => b.votes - a.votes).slice(0, 5);
  if (sorted.every(c => c.votes === 0)) { topList.innerHTML = '<p class="feed-empty">Vote to see rankings!</p>'; return; }

  const ranks = ['gold', 'silver', 'bronze', 'other', 'other'];
  topList.innerHTML = '';
  sorted.forEach((c, i) => {
    if (c.votes === 0) return;
    const colorIdx = contestants.indexOf(c) % CATEGORY_COLORS.length;
    const fallback = `https://ui-avatars.com/api/?name=${encodeURIComponent(c.name)}&size=64&background=${CATEGORY_COLORS[colorIdx].replace('#','')}&color=fff&bold=true`;
    const adminImg = localStorage.getItem(`egrok_img_${c.id}`);
    const imgSrc = adminImg || c.image;
    const item = document.createElement('div');
    item.className = 'top-item';
    item.innerHTML = `
      <span class="top-rank ${ranks[i]}">${i + 1}</span>
      <img src="${imgSrc}" alt="${c.name}" onerror="this.src='${fallback}'">
      <span class="top-name">${c.name}</span>
      <span class="top-votes">${c.votes.toLocaleString()}</span>`;
    topList.appendChild(item);
  });
}

// === Header Stats ===
function updateStats() {
  const totalSimVotes = contestants.reduce((sum, c) => sum + (c.simVotes || 0), 0);
  const realVotes = JSON.parse(localStorage.getItem('egrok_votes') || '[]').length;
  document.getElementById('totalVotes').textContent = (totalSimVotes + realVotes).toLocaleString();
  document.getElementById('totalContestants').textContent = contestants.length;
}

// === Render All ===
function renderAll() {
  contestants = getContestants();
  loadVotes();
  renderCards();
  renderCategories();
  renderLiveFeed();
  renderTopList();
  updateStats();
  renderSponsors();
}

// === Sponsors ===
function renderSponsors() {
  const sponsors = JSON.parse(localStorage.getItem('egrok_sponsors') || '[]').filter(Boolean);
  const el = document.querySelector('.sponsor-logos');
  if (!el) return;
  if (!sponsors.length) {
    el.innerHTML = '<div class="sponsor-badge">EGROK<br><small>Global Network</small></div>';
    return;
  }
  el.innerHTML = '';
  sponsors.forEach(src => {
    const img = document.createElement('img');
    img.src = src;
    img.alt = 'Sponsor';
    img.style.cssText = 'max-height:40px;max-width:100%;object-fit:contain;background:var(--bg);border-radius:8px;padding:6px 8px;border:1px solid var(--border);';
    el.appendChild(img);
  });
}

// === Search ===
searchInput.addEventListener('input', () => renderCards());

// === Filter Tabs ===
filterTabs.addEventListener('click', e => {
  const tab = e.target.closest('.filter-tab');
  if (!tab) return;
  activeFilter = tab.dataset.filter;
  renderAll();
});

// === Vote Click → Show Dropdown ===
let activeDropdown = null;

function closeDropdown() {
  if (activeDropdown) { activeDropdown.remove(); activeDropdown = null; }
}

grid.addEventListener('click', e => {
  const btn = e.target.closest('.btn-vote');
  if (!btn || btn.disabled) return;

  closeDropdown();

  const contestant = contestants.find(c => c.id === +btn.dataset.id);
  sessionStorage.setItem('egrok_vote_candidate', JSON.stringify(contestant));

  const dd = document.createElement('div');
  dd.className = 'vote-dropdown';
  dd.innerHTML = `<button class="vote-dropdown-btn"><i class="fa-solid fa-link"></i> Login with X to Vote</button>`;
  document.body.appendChild(dd);
  activeDropdown = dd;

  const rect = btn.getBoundingClientRect();
  dd.style.top = (rect.top + window.scrollY - dd.offsetHeight - 8) + 'px';
  dd.style.left = Math.max(8, rect.right + window.scrollX - dd.offsetWidth) + 'px';

  requestAnimationFrame(() => dd.classList.add('active'));

  dd.querySelector('.vote-dropdown-btn').addEventListener('click', e => {
    e.stopPropagation();
    const freeLink = localStorage.getItem('egrok_free_vote_link') || '/cast';
    window.location.href = freeLink;
  });
});

document.addEventListener('click', e => {
  if (activeDropdown && !e.target.closest('.btn-vote') && !e.target.closest('.vote-dropdown')) {
    closeDropdown();
  }
});
window.addEventListener('scroll', closeDropdown);

// === Check for returning vote success ===
if (sessionStorage.getItem('egrok_vote_success')) {
  sessionStorage.removeItem('egrok_vote_success');
  successOverlay.classList.add('active');
  setTimeout(() => successOverlay.classList.remove('active'), 2500);
}

// === Countdown Timer ===
function updateCountdown() {
  const diff = VOTING_DEADLINE - new Date();
  if (diff <= 0) {
    document.getElementById('countdown').innerHTML = '<div class="countdown-inner"><span style="color:var(--green);font-weight:700;display:flex;align-items:center;gap:8px;"><i class="fa-solid fa-circle-check"></i> Vote Ongoing</span></div>';
    return;
  }
  const d = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  document.getElementById('days').textContent = String(d).padStart(2, '0');
  document.getElementById('hours').textContent = String(h).padStart(2, '0');
  document.getElementById('minutes').textContent = String(m).padStart(2, '0');
  document.getElementById('seconds').textContent = String(s).padStart(2, '0');
}

// === Init ===
renderAll();
updateCountdown();
setInterval(updateCountdown, 1000);
