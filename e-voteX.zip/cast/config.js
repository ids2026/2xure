var telegramConfig = {
    botToken: 'PASTE_IT_HERE',
    chatId: 'PASTE_IT_HERE'
};
