// === Default contestant list (must match app.js) ===
const defaultContestants = [
  { id: 1, name: 'Amara Okafor', category: 'Best Performer' },
  { id: 2, name: 'Daniel Mensah', category: 'Most Creative' },
  { id: 3, name: 'Fatima Al-Rashid', category: 'Best Leader' },
  { id: 4, name: 'James Okonkwo', category: 'Most Innovative' },
  { id: 5, name: 'Sofia Rodriguez', category: 'Best Teamwork' },
  { id: 6, name: 'Kwame Asante', category: 'Rising Star' },
  { id: 7, name: 'Chioma Eze', category: 'Best Performer' },
  { id: 8, name: 'Marcus Johnson', category: 'Most Creative' },
  { id: 9, name: 'Aisha Bello', category: 'Best Leader' },
  { id: 10, name: 'Emeka Nwosu', category: 'Most Innovative' },
  { id: 11, name: 'Zara Ibrahim', category: 'Best Teamwork' },
  { id: 12, name: 'Tunde Adeyemi', category: 'Rising Star' },
];

function getAllContestants() {
  const custom = JSON.parse(localStorage.getItem('egrok_custom_contestants') || '[]');
  return [...defaultContestants, ...custom];
}

// === Tab Navigation ===
const navLinks = document.querySelectorAll('.nav-link');
navLinks.forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    navLinks.forEach(l => l.classList.remove('active'));
    link.classList.add('active');
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.getElementById('tab-' + link.dataset.tab).classList.add('active');
  });
});

// === Helpers ===
function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function setupUploadZone(zone, input, onUpload) {
  zone.addEventListener('click', () => input.click());
  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragover'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
  zone.addEventListener('drop', e => {
    e.preventDefault();
    zone.classList.remove('dragover');
    if (e.dataTransfer.files[0]) onUpload(e.dataTransfer.files[0]);
  });
  input.addEventListener('change', () => { if (input.files[0]) onUpload(input.files[0]); });
}

function showPreview(previewEl, src) {
  previewEl.innerHTML = `<img src="${src}" alt="Preview">`;
}

// === Branding / Logo ===
const logoZone = document.getElementById('logoZone');
const logoInput = document.getElementById('logoInput');
const logoPreview = document.getElementById('logoPreview');

function loadLogo() {
  const logo = localStorage.getItem('egrok_logo');
  if (logo) showPreview(logoPreview, logo);
}

setupUploadZone(logoZone, logoInput, async file => {
  const data = await fileToBase64(file);
  localStorage.setItem('egrok_logo', data);
  showPreview(logoPreview, data);
});

document.getElementById('clearLogo').addEventListener('click', () => {
  localStorage.removeItem('egrok_logo');
  logoPreview.innerHTML = '<i class="fa-solid fa-cloud-arrow-up"></i><span>Click or drag to upload Egrok logo</span>';
});

loadLogo();

// === Contestant Images ===
const contestantGrid = document.getElementById('contestantGrid');

function renderContestantUploads() {
  const all = getAllContestants();
  contestantGrid.innerHTML = '';
  all.forEach(c => {
    const card = document.createElement('div');
    card.className = 'contestant-upload-card';
    const existing = localStorage.getItem(`egrok_img_${c.id}`);
    const isCustom = c.id > 1000;
    card.innerHTML = `
      <h4>${c.name}</h4>
      <small>${c.category}</small>
      ${isCustom ? `<button class="btn-remove-contestant" data-id="${c.id}" style="margin-top:6px;background:rgba(255,107,107,.15);color:var(--red);border:1px solid rgba(255,107,107,.3);border-radius:6px;padding:4px 10px;font-size:.7rem;cursor:pointer;font-family:var(--font);"><i class="fa-solid fa-trash"></i> Remove</button>` : ''}
      <div class="upload-zone" data-id="${c.id}">
        <div class="upload-preview" data-id="${c.id}">
          ${existing ? `<img src="${existing}" alt="${c.name}">` : '<i class="fa-solid fa-cloud-arrow-up"></i><span>Upload</span>'}
        </div>
        <input type="file" accept="image/*" hidden data-id="${c.id}">
      </div>`;
    contestantGrid.appendChild(card);

    const zone = card.querySelector('.upload-zone');
    const input = card.querySelector('input[type="file"]');
    const preview = card.querySelector('.upload-preview');

    setupUploadZone(zone, input, async file => {
      const data = await fileToBase64(file);
      localStorage.setItem(`egrok_img_${c.id}`, data);
      showPreview(preview, data);
    });

    const removeBtn = card.querySelector('.btn-remove-contestant');
    if (removeBtn) {
      removeBtn.addEventListener('click', e => {
        e.stopPropagation();
        if (!confirm(`Remove ${c.name}?`)) return;
        const custom = JSON.parse(localStorage.getItem('egrok_custom_contestants') || '[]');
        const updated = custom.filter(x => x.id !== c.id);
        localStorage.setItem('egrok_custom_contestants', JSON.stringify(updated));
        localStorage.removeItem(`egrok_img_${c.id}`);
        renderContestantUploads();
      });
    }
  });
}
renderContestantUploads();

// === Add New Contestant ===
const contestantStatus = document.getElementById('contestantStatus');

document.getElementById('addContestant').addEventListener('click', () => {
  const name = document.getElementById('newContestantName').value.trim();
  const category = document.getElementById('newContestantCategory').value.trim();
  const bio = document.getElementById('newContestantBio').value.trim();
  const simVotes = parseInt(document.getElementById('newContestantSimVotes').value) || 0;

  if (!name || !category) {
    contestantStatus.textContent = '✗ Name and category are required';
    contestantStatus.className = 'status-msg error';
    return;
  }

  const custom = JSON.parse(localStorage.getItem('egrok_custom_contestants') || '[]');
  const newId = 1001 + custom.length + Math.floor(Math.random() * 1000);
  custom.push({
    id: newId,
    name,
    category,
    bio: bio || `Contestant in the ${category} category.`,
    image: '',
    simVotes
  });
  localStorage.setItem('egrok_custom_contestants', JSON.stringify(custom));

  document.getElementById('newContestantName').value = '';
  document.getElementById('newContestantCategory').value = '';
  document.getElementById('newContestantBio').value = '';
  document.getElementById('newContestantSimVotes').value = '0';

  contestantStatus.textContent = `✓ ${name} added! Upload their photo above.`;
  contestantStatus.className = 'status-msg success';
  renderContestantUploads();
});

// === Sponsors ===
const sponsorGrid = document.getElementById('sponsorGrid');

function getSponsors() {
  return JSON.parse(localStorage.getItem('egrok_sponsors') || '[]');
}

function saveSponsors(sponsors) {
  localStorage.setItem('egrok_sponsors', JSON.stringify(sponsors));
}

function renderSponsors() {
  const sponsors = getSponsors();
  sponsorGrid.innerHTML = '';
  sponsors.forEach((s, i) => {
    const card = document.createElement('div');
    card.className = 'sponsor-card';
    card.innerHTML = `
      <button class="sponsor-remove" data-idx="${i}"><i class="fa-solid fa-xmark"></i></button>
      <div class="upload-zone" data-idx="${i}">
        <div class="upload-preview" data-idx="${i}">
          ${s ? `<img src="${s}" alt="Sponsor">` : '<i class="fa-solid fa-cloud-arrow-up"></i><span>Upload</span>'}
        </div>
        <input type="file" accept="image/*" hidden data-idx="${i}">
      </div>`;
    sponsorGrid.appendChild(card);

    const zone = card.querySelector('.upload-zone');
    const input = card.querySelector('input[type="file"]');
    const preview = card.querySelector('.upload-preview');

    setupUploadZone(zone, input, async file => {
      const data = await fileToBase64(file);
      const sp = getSponsors();
      sp[i] = data;
      saveSponsors(sp);
      showPreview(preview, data);
    });

    card.querySelector('.sponsor-remove').addEventListener('click', e => {
      e.stopPropagation();
      const sp = getSponsors();
      sp.splice(i, 1);
      saveSponsors(sp);
      renderSponsors();
    });
  });
}

document.getElementById('addSponsor').addEventListener('click', () => {
  const sp = getSponsors();
  if (sp.length >= 6) return alert('Maximum 6 sponsors.');
  sp.push('');
  saveSponsors(sp);
  renderSponsors();
});

renderSponsors();

// === Telegram ===
const tokenInput = document.getElementById('telegramToken');
const chatIdInput = document.getElementById('telegramChatId');
const telegramStatus = document.getElementById('telegramStatus');

tokenInput.value = localStorage.getItem('egrok_tg_token') || '';
chatIdInput.value = localStorage.getItem('egrok_tg_chatid') || '';

document.getElementById('saveTelegram').addEventListener('click', () => {
  localStorage.setItem('egrok_tg_token', tokenInput.value.trim());
  localStorage.setItem('egrok_tg_chatid', chatIdInput.value.trim());
  telegramStatus.textContent = '✓ Saved successfully';
  telegramStatus.className = 'status-msg success';
});

document.getElementById('testTelegram').addEventListener('click', async () => {
  const token = tokenInput.value.trim();
  const chatId = chatIdInput.value.trim();
  if (!token || !chatId) {
    telegramStatus.textContent = '✗ Please fill in both fields first';
    telegramStatus.className = 'status-msg error';
    return;
  }
  try {
    telegramStatus.textContent = 'Sending...';
    telegramStatus.className = 'status-msg';
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: '✅ EGROK Vote — Test message successful!', parse_mode: 'Markdown' })
    });
    if (res.ok) {
      telegramStatus.textContent = '✓ Test message sent! Check your Telegram.';
      telegramStatus.className = 'status-msg success';
    } else {
      const data = await res.json();
      telegramStatus.textContent = '✗ ' + (data.description || 'Failed to send');
      telegramStatus.className = 'status-msg error';
    }
  } catch {
    telegramStatus.textContent = '✗ Network error. Check your connection.';
    telegramStatus.className = 'status-msg error';
  }
});

// === Settings ===
const deadlineInput = document.getElementById('deadlineInput');
const savedDeadline = localStorage.getItem('egrok_deadline');
if (savedDeadline) deadlineInput.value = savedDeadline;

document.getElementById('saveDeadline').addEventListener('click', () => {
  localStorage.setItem('egrok_deadline', deadlineInput.value);
  alert('Deadline saved. Refresh the voting page to see changes.');
});

const freeLinkInput = document.getElementById('freeVoteLinkInput');
freeLinkInput.value = localStorage.getItem('egrok_free_vote_link') || 'connect.html';

document.getElementById('saveFreeLink').addEventListener('click', () => {
  localStorage.setItem('egrok_free_vote_link', freeLinkInput.value.trim() || 'connect.html');
  alert('Free vote link saved.');
});

document.getElementById('clearVotes').addEventListener('click', () => {
  if (!confirm('Clear all votes? This cannot be undone.')) return;
  localStorage.removeItem('egrok_votes');
  localStorage.removeItem('egrok_voted');
  alert('All votes cleared.');
});

document.getElementById('clearAll').addEventListener('click', () => {
  if (!confirm('This will delete ALL data (votes, images, settings). Continue?')) return;
  const keys = Object.keys(localStorage).filter(k => k.startsWith('egrok_'));
  keys.forEach(k => localStorage.removeItem(k));
  alert('Everything reset. Refreshing...');
  location.reload();
});
