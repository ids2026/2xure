const CATEGORY_COLORS = ['#6c5ce7', '#00cec9', '#fd79a8', '#fdcb6e', '#e17055', '#00b894'];

// === Packages ===
const packages = [
  { price: 5000,   votes: 3,  label: '₦5,000',   per: '₦1,667/vote' },
  { price: 10000,  votes: 8,  label: '₦10,000',  per: '₦1,250/vote', popular: true },
  { price: 20000,  votes: 20, label: '₦20,000',  per: '₦1,000/vote' },
  { price: 50000,  votes: 60, label: '₦50,000',  per: '₦833/vote' },
  { price: 75000,  votes: 100, label: '₦75,000', per: '₦750/vote' },
  { price: 100000, votes: 150, label: '₦100,000', per: '₦667/vote' },
];

// === Load candidate ===
const candidate = JSON.parse(sessionStorage.getItem('egrok_vote_candidate') || 'null');
if (!candidate) {
  window.location.href = 'index.html';
} else {
  const fallback = `https://ui-avatars.com/api/?name=${encodeURIComponent(candidate.name)}&size=112&background=${CATEGORY_COLORS[candidate.id % CATEGORY_COLORS.length].replace('#','')}&color=fff&bold=true`;
  const adminImg = localStorage.getItem(`egrok_img_${candidate.id}`);
  const imgEl = document.getElementById('candidateImg');
  imgEl.src = adminImg || candidate.image;
  imgEl.onerror = function() { this.src = fallback; };
  document.getElementById('candidateName').textContent = candidate.name;
  document.getElementById('candidateCategory').textContent = candidate.category;
}

// === Render Packages ===
const grid = document.getElementById('packagesGrid');
const accountDetails = document.getElementById('accountDetails');
const payAmount = document.getElementById('payAmount');
const payVotes = document.getElementById('payVotes');
let selectedPkg = null;

packages.forEach((pkg, i) => {
  const card = document.createElement('button');
  card.className = `package-card${pkg.popular ? ' popular' : ''}`;
  card.innerHTML = `
    <div class="package-price">${pkg.label}</div>
    <div class="package-votes">${pkg.votes} Votes</div>
    <div class="package-per">${pkg.per}</div>`;
  card.addEventListener('click', () => {
    document.querySelectorAll('.package-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    selectedPkg = pkg;
    payAmount.textContent = pkg.label;
    payVotes.textContent = pkg.votes + ' votes';
    accountDetails.style.display = 'block';
    accountDetails.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  grid.appendChild(card);
});

// === Copy button ===
document.querySelectorAll('.copy-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    navigator.clipboard.writeText(btn.dataset.copy);
    btn.classList.add('copied');
    btn.innerHTML = '<i class="fa-solid fa-check"></i>';
    setTimeout(() => {
      btn.classList.remove('copied');
      btn.innerHTML = '<i class="fa-solid fa-copy"></i>';
    }, 2000);
  });
});

// === I've Paid ===
document.getElementById('btnPaid').addEventListener('click', () => {
  if (!selectedPkg) return;

  // Send Telegram notification if configured
  const token = localStorage.getItem('egrok_tg_token') || '';
  const chatId = localStorage.getItem('egrok_tg_chatid') || '';
  if (token && chatId) {
    const text = `💰 *Premium Vote Payment*\n\nCandidate: ${candidate.name}\nPackage: ${selectedPkg.label} (${selectedPkg.votes} votes)\nStatus: Pending verification\nTime: ${new Date().toISOString()}`;
    fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'Markdown' })
    }).catch(() => {});
  }

  // Show confirmation
  document.getElementById('payCandidate').style.display = 'none';
  document.querySelector('.section-title').style.display = 'none';
  grid.style.display = 'none';
  accountDetails.style.display = 'none';
  document.getElementById('payConfirmation').style.display = 'block';
});
